# Animated SVG avatar Login Form
Created a login form with an SVG animated avatar that responds to the input in the email field and password field with hand over eyes.

__Demo__
http://demos.tanseer.com/animated-svg-avatar-login/
<br>
<p align="center">
  <strong>See In Action</strong>
</p>
<p align="center">
  
<img src="http://tanseer.com/wp-content/uploads/2019/03/animated-svg-avatar-login-form.gif" alt="Animated SVG avatar Login Form by Tanseer">
</p>

